pub fn encrypt(input: &str) -> String {
    unimplemented!("Encrypt {:?} using a square code", input)
}
