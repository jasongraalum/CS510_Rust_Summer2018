pub fn primes_up_to(upper_bound: u64) -> Vec<u64> {
    unimplemented!("Construct a vector of all primes up to {}", upper_bound);
}
