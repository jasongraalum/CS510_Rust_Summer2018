/// Determines whether the supplied string is a valid ISBN number
pub fn is_valid_isbn(isbn: &str) -> bool {
    unimplemented!("Is {:?} a valid ISBN number?", isbn);
}
