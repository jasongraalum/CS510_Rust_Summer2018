pub fn reply(message: &str) -> &str {
    unimplemented!("have Bob reply to the incoming message: {}", message)
}
