extern crate pythagorean_triplet;

#[test]
fn test_answer() {
    assert_eq!(pythagorean_triplet::find(), Some(31875000));
}
